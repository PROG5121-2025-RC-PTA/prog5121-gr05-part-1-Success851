/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package reg.and.log;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class RegAndLog {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner Scanner =new Scanner(System.in);
        Login loginSystem =new login();
        
        System.out.println("Welcome to the registration and login Console App");
        boolean running =true;
        
        while(running){
            System.out.println("\nSelect on option:");
            System.out.println("1.Reg");
            System.out.println("2.Login");
            System.out.println("3. Exit");
            System.out.println("Choice:");
            int Choice =Scanner.nextInt();
            //consume newline
            Scanner.nextLine();
            
            switch(Choice){
                case 1:
                    System.out.print("Please enter First Name:");
                    String FirstName =Scanner.nextLine();
                    
                    System.out.print("Please enter Last Name:");
                    String LastName =Scanner.nextLine();
                    
                    System.out.print("Please enter username(must include_and be <=5 chars):");
                    String username =Scanner.nextLine();
                    
                    System.out.print("Please enter password(>=8 chars,uupercase,number.special char):");
                    String password =Scanner.nextLine();
                    
                    System.out.print("Please enter cellphone Number(e.g.+27867463216):");
                    String cellphone =Scanner.nextLine();
                    
                    String result =loginSystem.registeruser(username,password,cellphone,FirstName,LastName);
                    System.out.println(result);
                    break;
                    
                case 2:
                    System.out.print("Please enter username:");
                    String loginuser =Scanner.nextLine();
                    
                    System.out.print("Please enter password:");
                    String loginpass = Scanner.nextLine();
                    
                    boolean Success =loginSystem.loginuser(loginuser,loginpass);
                    System.out.println(loginSystem.returnloginstatus(loginuser));
                    break;
                    
                case 3:
                    System.out.println("Exiting the program...");
                    running =false;
                    
                //default
                    System.out.println("Invalid Choice.Please try again:");
                    
            }
            //spacing
            System.out.println();
        }
        Scanner.close();
    }
    
}
