/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class Poe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner Scanner =new Scanner(System.in);
        //Login loginSystem =new login();
        
        System.out.println("Welcome to the registration and login Console App");
        boolean running =true;
        
        while(running){
            System.out.println("\nSelect on option:");
            System.out.println("1.Reg");
            System.out.println("2.Login");
            System.out.println("3. Exit");
            System.out.println("Choice:");
            int Choice =Scanner.nextInt();
            //consume newline
            Scanner.nextLine();
    }
        switch(Choice){
                case 1:
                    
                    reg_login reg = new reg_login();
                    reg.reg();
                    break;
                    
                case 2:
                    System.out.print("Please enter username:");
                    String loginuser =Scanner.nextLine();
                    
                    System.out.print("Please enter password:");
                    String loginpass = Scanner.nextLine();
                    
                    boolean Success =loginSystem.loginuser(loginuser,loginpass);
                    System.out.println(loginSystem.returnloginstatus(loginuser));
                    break;

                    
                    break;
                    
                case 3:
                    System.out.println("Exiting the program...");
                    running =false;
                    
                //default
                    System.out.println("Invalid Choice.Please try again:");
        }
    
}
}
