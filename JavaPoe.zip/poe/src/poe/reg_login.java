/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class reg_login {
    public static void reg(){
        Scanner Scanner = new Scanner(System.in);
        System.out.print("Please enter First Name:");
                    System.out.print("Please enter First Name:");
                    String FirstName =Scanner.nextLine();
                    
                    System.out.print("Please enter Last Name:");
                    String LastName =Scanner.nextLine();
                    
                    System.out.print("Please enter username(must include_and be <=5 chars):");
                    String username =Scanner.nextLine();
                    
                    
                    System.out.print("Please enter password(>=8 chars,uupercase,number.special char):");
                    String password =Scanner.nextLine();
                    
                    do{
                    System.out.print("Please enter cellphone Number(e.g.+27867463216):");
                    String cellphone = Scanner.nextLine();
                    }while(!checkcellphoneNumber(cellphone));
                    
                    //String result =loginSystem.registeruser(username,password,cellphone,FirstName,LastName);
    }

 
  
      
    public boolean checkusername(String username){
          return username.contains("_")&& username.length()<=5;
      }
      public boolean checkpasswordcomplexity(String password){
          return password.matches(".*[a-z].*")&&
                 password.matches(".*\\d.*")&&
                 password.matches(password);
      }
      
     public boolean checkcellphoneNumber(String cellphone) {
         return cellphone.matches("^\\+27\\d{9}$");
     }
     
     
     public String registeruser(String username,String password, String cellphone,String Firstname, String Lastname){
         if (checkusername (username)){
             return"username is incorrectly formatted must contains an uderscore and be no more than 5 characters.";
         }
         if (!checkpasswordcomplexity(password)){
             return"password does not meet complexity requirements.";
         }
         if(!checkcellphoneNumber(cellphone)){
             return"cellphone number is incorrectly formatted.";
         }
         //registereduser.put(username,password,cellphone,Firstname,Lastname);
         return"user registered successfully.";
             
            
         }
    }
   

